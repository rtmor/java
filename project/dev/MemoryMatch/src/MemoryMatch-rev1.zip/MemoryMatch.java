import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.animation.Animation;
import javafx.animation.AnimationTimer;
import javafx.animation.FadeTransition;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class MemoryMatch extends Application {

    @FXML
    private StackPane gamePane;

    @FXML
    private VBox menuPane;

    @FXML
    private AnchorPane leftPane;

    @FXML
    private ResourceBundle resources;

    @FXML
    private BorderPane rootPane;

    @FXML
    private Label clockWatch;

    @FXML
    private ComboBox<String> challengeMenu;

    @FXML
    private Label winnerLabel;

    @FXML
    private URL location;

    private static int PAIR_COUNT = 18;
    private static int NUM_PER_ROW = 6;

    private Tile selected = null;
    private int clickCount = 2;
    private AnimationTimer stopclock;
    private FadeTransition winFade;

    @FXML
    void initialize() {
        rootPane.setBackground(new Background(new BackgroundFill(Color.web("#f2f2e4"), null, null)));
        menuPane.setBackground(new Background(new BackgroundFill(Color.web("#3b4252"), null, null)));
        Group content = createContent();
        // gamePane.getChildren().add(new VBox(new HBox(createContent())));
        gamePane.getChildren().add(content);
        StackPane.setAlignment(content, Pos.CENTER);
        buildChallengeMenu();
        stopclock = setTimer();
        stopclock.start();
    }

    @FXML
    void restart(ActionEvent event) {

        switch (challengeMenu.getValue()) {
        case "Easy":
            NUM_PER_ROW = 4;
            PAIR_COUNT = 8;
            break;
        case "Medium":
            NUM_PER_ROW = 6;
            PAIR_COUNT = 18;
            break;
        case "Hard":
            NUM_PER_ROW = 10;
            PAIR_COUNT = 50;
            break;
        case "Impossible":
            NUM_PER_ROW = 20;
            PAIR_COUNT = 200;
            break;
        }

        winnerLabel.setVisible(false);

        try {
            winFade.stop();
        } catch (Exception e) {
        }

        stopclock.stop();
        gamePane.getChildren().clear();

        initialize();

    }

    @FXML
    void clear(ActionEvent event) {

        stopclock.stop();
        gamePane.getChildren().clear();

        try {
            winFade.stop();
        } catch (Exception e) {
        }

    }

    private void buildChallengeMenu() {
        challengeMenu.getItems().setAll("Easy", "Medium", "Hard", "Impossible");
        challengeMenu.setValue("Medium");
    }

    private AnimationTimer setTimer() {
        AnimationTimer timer = new AnimationTimer() {
            private long timestamp;
            private long time = 0;
            private long fraction = 0;

            @Override
            public void start() {
                // current time adjusted by remaining time from last run
                timestamp = System.currentTimeMillis() - fraction;
                super.start();
            }

            @Override
            public void stop() {
                super.stop();
                // save leftover time not handled with the last update
            }

            @Override
            public void handle(long now) {
                long newTime = System.currentTimeMillis();
                if (timestamp + 1000 <= newTime) {
                    long deltaT = (newTime - timestamp) / 1000;
                    time += deltaT;
                    timestamp += 1000 * deltaT;
                    clockWatch.setText(String.format("%02d seconds", time));
                }
            }
        };

        return timer;
    }

    private Group createContent() {
        Group root = new Group();
        int size = 600 / NUM_PER_ROW;

        List<Tile> tiles = new ArrayList<>();
        for (int i = 0; i < PAIR_COUNT; i++) {
            Color c = getColor();
            tiles.add(new Tile(c));
            tiles.add(new Tile(c));
        }

        Collections.shuffle(tiles);

        for (int i = 0; i < tiles.size(); i++) {
            Tile tile = tiles.get(i);
            tile.setTranslateX(size * (i % NUM_PER_ROW));
            tile.setTranslateY(size * (i / NUM_PER_ROW));
            root.getChildren().add(tile);
        }

        return root;
    }

    private Color getColor() {

        Random random = new Random();

        float r = random.nextFloat();
        float g = random.nextFloat();
        float b = random.nextFloat();

        Color color = new Color(r, g, b, 1);

        return color;
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("MemoryMatch.fxml"));
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Memory Match Game");
        primaryStage.show();
        primaryStage.sizeToScene();
    }

    private class Tile extends StackPane {
        private String id;
        private Rectangle border;

        public Tile(Color value) {

            int size = 600 / NUM_PER_ROW;

            Rectangle fill = new Rectangle(size, size);
            fill.setFill(null);
            fill.setStroke(Color.BLACK);

            border = new Rectangle(size, size);
            border.setFill(value);

            id = value.toString();

            setAlignment(Pos.CENTER);
            getChildren().addAll(border, fill);

            setOnMouseClicked(this::handleMouseClick);
            close();
        }

        public void handleMouseClick(MouseEvent event) {
            if (isOpen() || clickCount == 0)
                return;

            clickCount--;

            if (selected == null) {
                selected = this;
                open(() -> {
                });
            } else {
                open(() -> {
                    if (!equalValue(selected)) {
                        selected.close();
                        this.close();
                    } else {
                        PAIR_COUNT--;

                        if (PAIR_COUNT == 0) {
                            stopclock.stop();
                            winner();
                        }
                    }

                    selected = null;
                    clickCount = 2;
                });
            }
        }

        public boolean isOpen() {
            return border.getOpacity() == 1;
        }

        public void open(Runnable action) {
            FadeTransition ft = new FadeTransition(Duration.seconds(0.5), border);
            ft.setToValue(1);
            ft.setOnFinished(e -> action.run());
            ft.play();
        }

        public void close() {
            FadeTransition ft = new FadeTransition(Duration.seconds(0.5), border);
            ft.setToValue(0);
            ft.play();
        }

        public boolean equalValue(Tile other) {
            return id.equals(other.id);
        }
    }

    private void winner() {

        winnerLabel.setVisible(true);

        winFade = new FadeTransition(Duration.seconds(0.2), winnerLabel);
        winFade.setFromValue(1.0);
        winFade.setToValue(0.0);
        winFade.setAutoReverse(true);
        winFade.setCycleCount(Animation.INDEFINITE);
        winFade.play();

    }

    public static void main(String[] args) {
        launch(args);
    }
}