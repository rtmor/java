import java.io.IOException;

import javafx.animation.FadeTransition;
import javafx.geometry.Pos;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.util.Duration;

class Tile extends StackPane {
    /**
     *
     */
    private final MemoryMatch memoryMatch;
    private String id;
    private Rectangle border;

    public Tile(MemoryMatch memoryMatch, Color value) {

        this.memoryMatch = memoryMatch;
        int size = 600 / MemoryMatch.NUM_PER_ROW;

        Rectangle fill = new Rectangle(size, size);
        fill.setFill(null);
        fill.setStroke(Color.BLACK);

        border = new Rectangle(size, size);
        border.setFill(value);

        id = value.toString();

        setAlignment(Pos.CENTER);
        getChildren().addAll(border, fill);

        setOnMouseClicked(this::handleMouseClick);
        close();
    }

    public void handleMouseClick(MouseEvent event) {
        if (isOpen() || this.memoryMatch.clickCount == 0)
            return;

        this.memoryMatch.clickCount--;

        if (this.memoryMatch.selected == null) {
            this.memoryMatch.selected = this;
            open(() -> {
            });
        } else {
            open(() -> {
                if (!equalValue(this.memoryMatch.selected)) {
                    this.memoryMatch.selected.close();
                    this.close();
                } else {
                    MemoryMatch.PAIR_COUNT--;

                    if (MemoryMatch.PAIR_COUNT == 0) {
                        this.memoryMatch.stopclock.stop();
                        try {
                            this.memoryMatch.winner();
                        } catch (IOException e) {
                            // TODO Auto-generated catch block
                            e.printStackTrace();
                        }
                    }
                }

                this.memoryMatch.selected = null;
                this.memoryMatch.clickCount = 2;
            });
        }
    }

    public boolean isOpen() {
        return border.getOpacity() == 1;
    }

    public void open(Runnable action) {
        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), border);
        ft.setToValue(1);
        ft.setOnFinished(e -> action.run());
        ft.play();
    }

    public void close() {
        FadeTransition ft = new FadeTransition(Duration.seconds(0.5), border);
        ft.setToValue(0);
        ft.play();
    }

    public boolean equalValue(Tile other) {
        return id.equals(other.id);
    }
}